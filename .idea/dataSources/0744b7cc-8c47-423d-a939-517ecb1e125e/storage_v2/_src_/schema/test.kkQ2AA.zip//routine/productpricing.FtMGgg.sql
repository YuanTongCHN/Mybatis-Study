create
    definer = root@localhost procedure productpricing(OUT pl decimal(8, 2), OUT ph decimal(8, 2), OUT pa decimal(8, 2))
BEGIN
		SELECT Avg(prod_price)
		INTO pa
		FROM products;
		SELECT Min(prod_price)
		INTO pl
		FROM products;
		SELECT Max(prod_price)
		INTO ph
		FROM products;
 END;

