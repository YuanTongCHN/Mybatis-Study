create
    definer = root@localhost procedure processorder()
BEGIN
		DECLARE o INT;
		DECLARE done TINYINT DEFAULT 0 ;
		
		DECLARE ordernumbers CURSOR 
		FOR
		SELECT order_num from orders;		
		
		
		DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
		
		open ordernumbers;
		
		REPEAT
				FETCH ordernumbers INTO o;
				SELECT 0;
		UNTIL done = 1 END REPEAT;
		
		CLOSE ordernumbers;
 END;

