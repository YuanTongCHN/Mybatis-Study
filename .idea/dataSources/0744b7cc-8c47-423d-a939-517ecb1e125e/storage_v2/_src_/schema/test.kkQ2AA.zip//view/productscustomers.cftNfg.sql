create view productscustomers as
select `test`.`customers`.`cust_name`    AS `cust_name`,
       `test`.`customers`.`cust_contact` AS `cust_contact`,
       `test`.`orderitems`.`prod_id`     AS `prod_id`
from `test`.`customers`
         join `test`.`orders`
         join `test`.`orderitems`
where ((`test`.`customers`.`cust_id` = `test`.`orders`.`cust_id`) and
       (`test`.`orders`.`order_num` = `test`.`orderitems`.`order_num`));

